package com.example.TimeTable;

import java.util.List;

public class TimeTableContainer {
	private String classId;
	private int additionlCoTeacher;
	private List<ClassTimeTable> listClassTT;
	private List<CoTeacherTimeTable> listCoTeacherTT;

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public List<ClassTimeTable> getListClassTT() {
		return listClassTT;
	}

	public void setListClassTT(List<ClassTimeTable> listClassTT) {
		this.listClassTT = listClassTT;
	}

	public List<CoTeacherTimeTable> getListCoTeacherTT() {
		return listCoTeacherTT;
	}

	public void setListCoTeacherTT(List<CoTeacherTimeTable> listCoTeacherTT) {
		this.listCoTeacherTT = listCoTeacherTT;
	}

	public int getAdditionlCoTeacher() {
		return additionlCoTeacher;
	}

	public void setAdditionlCoTeacher(int additionlCoTeacher) {
		this.additionlCoTeacher = additionlCoTeacher;
	}
}
