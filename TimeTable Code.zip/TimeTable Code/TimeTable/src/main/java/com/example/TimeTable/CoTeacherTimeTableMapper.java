package com.example.TimeTable;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class CoTeacherTimeTableMapper implements RowMapper<CoTeacherTimeTable> {

	public CoTeacherTimeTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		CoTeacherTimeTable tt = new CoTeacherTimeTable();
		tt.setId(rs.getInt("id"));
		tt.setClassId(rs.getString("class"));
		tt.setDay(rs.getString("day"));
		tt.setTime(rs.getString("time"));
		tt.setTeacher(rs.getString("teacher"));
		tt.setCoTeacher(rs.getString("coteacher"));
		return tt;
	}
}
