package com.example.TimeTable;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TimeTableRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void createClassTimeTableFormat(String classId, String time) {
		String insertQuery = "insert into classTimeTable (class, time,monday,tuesday,wednesday,thursday,friday,saturday) values (?, ?,?,?,?,?,?,?)";
		jdbcTemplate.update(insertQuery, classId, time, null, null, null, null, null, null);
	}

	public void updateClassTimeTable(String classId, String time, String day, String subject) {
		String updateQuery = "update classTimeTable set " + day + "=?  where class = ? and time=?";
		jdbcTemplate.update(updateQuery, subject, classId, time);
	}

	@SuppressWarnings("deprecation")
	public List<ClassTimeTable> getClassTimeTable(String classId) {
		String sql = "SELECT * FROM classTimeTable where class =?";

		List<ClassTimeTable> listCTT = jdbcTemplate.query(sql, new Object[] { classId }, new ClassTimeTableMapper());
		return listCTT;
	}

	public void createTimeTable(String classId, String time, String day, String teacher, String isCoTeacher) {
		String insertQuery = "insert into CoTeacherTimeTable (class, time,day,teacher,coteacher,isCoteacher) values (?, ?,?,?,?,?)";
		jdbcTemplate.update(insertQuery, classId, time, day, teacher, null, isCoTeacher);
		// System.out.println("Created Record Name = " + name + " Age = " + age);
		return;
	}

	@SuppressWarnings("deprecation")
	public List<CoTeacherTimeTable> getIdleTeacher(String time, String day) {
		String sql = "SELECT * FROM CoTeacherTimeTable where class IS NULL and time = ? and day=?";

		List<CoTeacherTimeTable> listTT = jdbcTemplate.query(sql, new Object[] { time, day },
				new CoTeacherTimeTableMapper());
		return listTT;
	}

	@SuppressWarnings("deprecation")
	public List<CoTeacherTimeTable> getActiveTeacher(String time, String day) {
		String sql = "SELECT * FROM CoTeacherTimeTable where class IS NOT NULL and time = ? and day=?";

		List<CoTeacherTimeTable> listTT = jdbcTemplate.query(sql, new Object[] { time, day },
				new CoTeacherTimeTableMapper());
		return listTT;
	}

	public List<CoTeacherTimeTable> getclassTT(String classId) {
		String sql = "SELECT * FROM CoTeacherTimeTable where class ='" + classId
				+ "' and coteacher is not null order by id;";

		List<CoTeacherTimeTable> listTT = jdbcTemplate.query(sql, new CoTeacherTimeTableMapper());
		return listTT;
	}

	public void updateActiveTeacher(CoTeacherTimeTable tt) {
		String updateQuery = "update CoTeacherTimeTable set coteacher=?  where id=?";
		jdbcTemplate.update(updateQuery, tt.getCoTeacher(), tt.getId());
	}

	public void updateIdleTeacher(CoTeacherTimeTable tt) {
		String updateQuery = "update CoTeacherTimeTable set class=?  where id=?";
		jdbcTemplate.update(updateQuery, tt.getClassId(), tt.getId());
		System.out.println(tt.getClassId() + tt.getId());
	}

	public int getExtraCoTeacherRequired() {
		String sql = "select count(*) as pending from CoTeacherTimeTable where coteacher is  null and iscoteacher='N' group by time,day order by pending desc limit 1;";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

}
