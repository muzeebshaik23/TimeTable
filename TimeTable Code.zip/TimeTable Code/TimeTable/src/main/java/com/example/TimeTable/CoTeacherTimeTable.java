package com.example.TimeTable;

public class CoTeacherTimeTable {
	private int id;
	private String classId;
	private String time;
	private String day;
	private String teacher;
	private String coTeacher;

	public String getCoTeacher() {
		return coTeacher;
	}

	public void setCoTeacher(String coTeacher) {
		this.coTeacher = coTeacher;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
