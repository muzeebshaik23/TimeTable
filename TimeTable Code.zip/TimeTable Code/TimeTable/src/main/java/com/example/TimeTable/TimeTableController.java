package com.example.TimeTable;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class TimeTableController {
	@Autowired
	TimeTableRepository timeTableRepository;
	Map<Integer, String> dayMap = new TreeMap<>();

	@GetMapping("/getClassTimeTable")
	public ModelAndView classTimeTable(Model model) {

		List<ClassTimeTable> listClassTT = timeTableRepository.getClassTimeTable("6th");
		List<CoTeacherTimeTable> listCoTeacherTT = timeTableRepository.getclassTT("6th");
		int additionlCoTeacher=timeTableRepository.getExtraCoTeacherRequired();
		TimeTableContainer ttc = new TimeTableContainer();
		ttc.setClassId("6th");
		ttc.setAdditionlCoTeacher(additionlCoTeacher);
		ttc.setListClassTT(listClassTT);
		ttc.setListCoTeacherTT(listCoTeacherTT);
		return new ModelAndView("classTimeTable", "TimeTableContainer", ttc);

	}

	@GetMapping("/selectedClassTimeTable")
	public ModelAndView selectedClassTimeTable(@ModelAttribute("TimeTableContainer") TimeTableContainer ttc) {
		List<ClassTimeTable> listClassTT = timeTableRepository.getClassTimeTable(ttc.getClassId());
		List<CoTeacherTimeTable> listCoTeacherTT = timeTableRepository.getclassTT(ttc.getClassId());
		ttc.setListClassTT(listClassTT);
		ttc.setListCoTeacherTT(listCoTeacherTT);
		return new ModelAndView("classTimeTable", "TimeTableContainer", ttc);
	}

	public void createClassTimeTableFormat() {

		String[] periods = { "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM",
				"4:00 PM" };
		String[] classes = { "6th", "7th", "8th", "9th", "10th" };
		for (String c : classes) {
			for (String period : periods) {
				timeTableRepository.createClassTimeTableFormat(c, period);
			}
		}
	}

	@GetMapping("/generateTimeTable")
	public String generateTimeTable() {
		createClassTimeTableFormat();
		this.dayMap.put(1, "Monday");
		this.dayMap.put(2, "Tuesday");
		this.dayMap.put(3, "Wednesday");
		this.dayMap.put(4, "Thursday");
		this.dayMap.put(5, "Friday");
		this.dayMap.put(6, "Saturday");
		saveCSVData("English", "src/main/resources/Teacher wise class timetable - English.csv");
		saveCSVData("Hindi", "src/main/resources/Teacher wise class timetable - Hindi.csv");
		saveCSVData("Kannada", "src/main/resources/Teacher wise class timetable - Kannada.csv");
		saveCSVData("Maths", "src/main/resources/Teacher wise class timetable - Maths.csv");
		saveCSVData("Science", "src/main/resources/Teacher wise class timetable - Science.csv");
		generatecoTeacher();
		return "CSV data inserted in database";
	}

	public void saveCSVData(String subject, String path) {
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			br.readLine();// to remove headers
			String line;
			String period = "";
			while ((line = br.readLine()) != null) {
				String[] values = line.split(",", -1);
				period = values[0];
				for (int i = 1; i < values.length; i++) {
					timeTableRepository.updateClassTimeTable(values[i], period, this.dayMap.get(i), subject);
					if (values[i].length() > 0) {
						timeTableRepository.createTimeTable(values[i], period, this.dayMap.get(i), subject, "N");
					} else {
						timeTableRepository.createTimeTable(null, period, this.dayMap.get(i), subject, "Y");
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void generatecoTeacher() {
		String[] periods = { "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM",
				"4:00 PM" };
		String[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		for (String day : days) {
			for (String period : periods) {
				List<CoTeacherTimeTable> listidleTT = timeTableRepository.getIdleTeacher(period, day);
				if (listidleTT != null && listidleTT.size() != 0) {
					List<CoTeacherTimeTable> listActiveTT = timeTableRepository.getActiveTeacher(period, day);
					if (listActiveTT != null && listActiveTT.size() != 0) {
						alignCoteacher(listidleTT, listActiveTT);
					}
				}
			}

		}
	}

	public void alignCoteacher(List<CoTeacherTimeTable> listidleTT, List<CoTeacherTimeTable> listActiveTT) {
		for (int i = 0; i < listActiveTT.size(); i++) {
			if (i < listidleTT.size()) {
				CoTeacherTimeTable idleTeacher = listidleTT.get(i);
				CoTeacherTimeTable activeTeacher = listActiveTT.get(i);
				activeTeacher.setCoTeacher(idleTeacher.getTeacher());
				idleTeacher.setClassId(activeTeacher.getClassId());
				timeTableRepository.updateActiveTeacher(activeTeacher);
				timeTableRepository.updateIdleTeacher(idleTeacher);
			} else
				break;
		}
	}

}
