package com.example.TimeTable;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ClassTimeTableMapper implements RowMapper<ClassTimeTable> {

	public ClassTimeTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		ClassTimeTable ctt = new ClassTimeTable();
		ctt.setClassId(rs.getString("class"));
		ctt.setTime(rs.getString("time"));
		ctt.setMonday(rs.getString("monday"));
		ctt.setTuesday(rs.getString("tuesday"));
		ctt.setWednesday(rs.getString("wednesday"));
		ctt.setThursday(rs.getString("thursday"));
		ctt.setFriday(rs.getString("friday"));
		ctt.setSaturday(rs.getString("saturday"));
		return ctt;
	}
}
