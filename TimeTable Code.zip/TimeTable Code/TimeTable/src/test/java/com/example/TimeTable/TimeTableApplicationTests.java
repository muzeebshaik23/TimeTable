package com.example.TimeTable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeTableApplicationTests {

	@Test
	void contextLoads() {
	}

}
